/*
Theme Name:     Xstore
Theme URI:      https://xstore.8theme.com
Author:         8theme
Author URI:     https://www.8theme.com
Description:    XStore is a multi-purpose theme that offers the ultimate WordPress and WooCommerce synergy, providing a comprehensive, all-in-one solution.
Version:        9.5
Tested up to:   6.8
Requires PHP:   7.0
WC requires at least: 4.7
License:        GNU General Public License version 3.0
License URI:    http://www.gnu.org/licenses/gpl-3.0.html
Text Domain:    xstore
Tags: e-commerce, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, custom-logo, featured-images, full-width-template, threaded-comments, accessibility-ready, rtl-language-support, footer-widgets, sticky-post, theme-options, translation-ready, ecommerce, woocommerce, shop, elementor, business, corporate, blog, news, light, dark
*/
